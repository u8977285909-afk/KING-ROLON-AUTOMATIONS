KING ROLON AUTOMATIONS – Overlay Pack Warzone Navidad 🎄👑

Este es un paquete de ejemplo para el Marketplace del Reino.
Puedes usarlo como base para futuros packs reales (overlays, escenas, assets, etc.).

Contenido:
- overlays/ → aquí irían las imágenes PNG del overlay (marcos, banners, alertas…)
- config/   → configuración de ejemplo para tu app / automatización
- scripts/  → script de ejemplo en Python con la estructura básica

Este ZIP es solo DEMO, pensado para probar el flujo del Marketplace:
1. Subir archivo
2. Publicar app
3. Descargar desde otro usuario
4. Registrar venta/descarga en la BD

KING ROLON LEGACY 👑🔥