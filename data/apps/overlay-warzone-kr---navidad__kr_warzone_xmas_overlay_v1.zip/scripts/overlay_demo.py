# -*- coding: utf-8 -*-
"""
KING ROLON AUTOMATIONS – Ejemplo de script para un Overlay Pack

Este archivo NO hace nada "mágico" todavía.
Solo muestra cómo podrías estructurar un módulo de automatización real
para trabajar con tus overlays dentro del ecosistema KING ROLON.

Ideas para la versión real:
- Leer un archivo de config (JSON) con escenas
- Generar automáticamente una estructura de carpetas para OBS
- Renombrar archivos PNG/JPG con un patrón estándar
- Exportar un pequeño "manifest" con info del pack
"""

from pathlib import Path
import json


BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "config" / "overlay_config.json"


def load_overlay_config():
    """Carga y devuelve la configuración del overlay pack."""
    if not CONFIG_PATH.exists():
        raise FileNotFoundError(f"No se encontró el archivo de configuración: {CONFIG_PATH}")
    with CONFIG_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def main():
    config = load_overlay_config()
    print("=== KING ROLON OVERLAY PACK ===")
    print(f"Nombre: {config.get('name')}")
    print(f"Versión: {config.get('version')}")
    print(f"Autor: {config.get('author')}")
    print("Escenas incluidas:")
    for scene in config.get("scenes", []):
        print(f"  - {scene}")
    print("\nEste script es solo demo. Aquí podrías añadir lógica real para automatizar tu setup. 👑🔥")


if __name__ == "__main__":
    main()
